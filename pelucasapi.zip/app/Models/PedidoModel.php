<?php

namespace App\Models;

use App\Entities\EmpresaEntity;
use App\Entities\Noticia;
use App\Entities\NoticiaEntity;
use App\Entities\PedidoEntity;
use App\Entities\ProductoBaseEntity;
use App\Entities\ProductoEntity;
use CodeIgniter\Model;

class PedidoModel extends Model
{
    protected $table      = 'pedido';
    protected $primaryKey = 'idpedido';

    protected $useAutoIncrement = true;

    protected $returnType     = PedidoEntity::class;
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'idestado',
        'idusuario',
        'idformapago',
        'identrega',
        'idppago',
        'referencia',
        'peso',
        'costoenvio',
        'comision',
        'subtotal',
        'descuento',
        'total',
        'fechapedido',
        'fechaentrega',
        'observacion',
        'urlconstancia',
        'fechareporte',
        'fechaconfirmacion',

    ];

    protected $useTimestamps = false;
    protected $createdField  = 'fecha';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


    public function getPedidoConUsuario($idpedido)
    {
        $pedido = $this->find($idpedido);

        if ($pedido) {
            $usuarioModel = new UsuarioModel();
            $pedido->usuario = $usuarioModel->find($pedido->idusuario);
        }

        return $pedido;
    }

    public function pedidoFindTotal($parametro, $valor, $idestado, $idusuario, $idformapago, $identrega, $idppago, $fecharango)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');

        $builder->select('p.*');

        if ($parametro != '' && $valor != '') {
            if ($parametro == 'referencia') {
                $builder->like('p.referencia', $valor);
            } elseif ($parametro == 'fecha') {
                $builder->where('p.fecha', $valor);
            } elseif ($parametro == 'nombres') {
                $builder->join('usuario u', 'u.idusuario = p.idusuario');
                $builder->where("CONCAT(u.nombres, ' ', u.papellido, ' ', u.sapellido) LIKE", "%$valor%");
            } elseif ($parametro == 'mes') {
                $builder->where('MONTH(p.fecha)', $valor);
            }
        }

        if ($idestado > 0) $builder->where('p.idestado', $idestado);
        if ($idusuario > 0) $builder->where('p.idusuario', $idusuario);
        if ($idformapago > 0) $builder->where('p.idformapago', $idformapago);
        if ($identrega > 0) $builder->where('p.identrega', $identrega);
        if ($idppago > 0) $builder->where('p.idppago', $idppago);

        if (!empty($fecharango)) {
            $builder->where('p.fechapedido >=', "$fecharango 00:00:00");
            $builder->where('p.fechapedido <=', "$fecharango 23:59:59");
        }

        return $builder->countAllResults();
    }

    public function pedidoFind($ordencriterio, $ordentipo, $parametro, $valor, $idestado, $idusuario, $idformapago, $identrega, $idppago, $fecharango, $inicio, $registros)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');

        $builder->select('p.*');

        if ($parametro != '' && $valor != '') {
            if ($parametro == 'referencia') {
                $builder->like('p.referencia', $valor);
            } elseif ($parametro == 'fecha') {
                $builder->where('p.fecha', $valor);
            } elseif ($parametro == 'nombres') {
                $builder->join('usuario u', 'u.idusuario = p.idusuario');
                $builder->where("CONCAT(u.nombres, ' ', u.papellido, ' ', u.sapellido) LIKE", "%$valor%");
            } elseif ($parametro == 'mes') {
                $builder->where('MONTH(p.fecha)', $valor);
            }
        }

        if ($idestado > 0) $builder->where('p.idestado', $idestado);
        if ($idusuario > 0) $builder->where('p.idusuario', $idusuario);
        if ($idformapago > 0) $builder->where('p.idformapago', $idformapago);
        if ($identrega > 0) $builder->where('p.identrega', $identrega);
        if ($idppago > 0) $builder->where('p.idppago', $idppago);

        if (!empty($fecharango)) {
            $builder->where('p.fechapedido >=', "$fecharango 00:00:00");
            $builder->where('p.fechapedido <=', "$fecharango 23:59:59");
        }

        if ($ordencriterio !== '' && $ordentipo !== '') {
            $builder->orderBy($ordencriterio, $ordentipo);
        }

        if ($inicio >= 0 && $registros > 0) {
            $builder->limit($registros, $inicio);
        }

        return $builder->get()->getResult();
    }

    public function obtenerPedido($idpedido)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');

        $builder->select('p.*, (SELECT pa.nombre FROM parametro pa WHERE pa.idparametro = p.idppago) as pago');
        $builder->where('p.idpedido', $idpedido);

        return $builder->get()->getRow();
    }

    public function pedidoTotalSuma($parametro, $valor, $idestado, $idppago)
    {
        $builder = $this->builder();

        if ($parametro != '' && $valor != '') {
            if ($parametro == 'mes') {
                $builder->where('MONTH(fecha)', $valor);
            } else {
                $builder->like($parametro, $valor);
            }
        }

        if ($idestado > 0) $builder->where('idestado', $idestado);
        if ($idppago > 0) $builder->where('idppago', $idppago);

        return $builder->selectSum('total')->get()->getRow()->total ?? 0;
    }
    //total de pedidos
    public function contarPedidosPorEmpresa(int $idempresa): int
    {
        return $this->where('idempresa', $idempresa)
            ->countAllResults();
    }
    //suma de total de pedidos 
    public function sumarTotalPedidosPorEmpresa(int $idempresa): float
    {
        return $this->selectSum('total')
            ->where('idempresa', $idempresa)
            ->get()
            ->getRow()
            ->total ?? 0;
    }

    public function pedidoTotalCantidad($parametro, $valor, $idestado, $idppago)
    {
        $builder = $this->builder();

        if ($parametro != '' && $valor != '') {
            if ($parametro == 'mes') {
                $builder->where('MONTH(fecha)', $valor);
            } else {
                $builder->like($parametro, $valor);
            }
        }

        if ($idestado > 0) $builder->where('idestado', $idestado);
        if ($idppago > 0) $builder->where('idppago', $idppago);

        return $builder->countAllResults();
    }

    public function obtenerPedidosPorCupon($idcupon)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');
        $builder->join('pedido_cupon', 'pedido_cupon.idpedido = p.idpedido');
        $builder->where('pedido_cupon.idcupon', $idcupon);

        return $builder->countAllResults();
    }

    public function obtenerByIdCuponIdProducto($idcupon, $idproducto)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');
        $builder->join('pedido_cupon', 'pedido_cupon.idpedido = p.idpedido');
        $builder->join('pedidodetalle', 'pedidodetalle.idpedido = p.idpedido');
        $builder->where('pedido_cupon.idcupon', $idcupon);
        $builder->where('pedidodetalle.idproducto', $idproducto);

        return $builder->countAllResults();
    }

    public function obtenerByIdCuponIdUsuario($idcupon, $idusuario)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');
        $builder->join('pedido_cupon', 'pedido_cupon.idpedido = p.idpedido');
        $builder->where('pedido_cupon.idcupon', $idcupon);
        $builder->where('p.idusuario', $idusuario);

        return $builder->countAllResults();
    }

    public function pedidoTotalSumaFiltrado($idusuario = null, $idestado = null)
    {
        $builder = $this->builder();

        if ($idusuario !== null) {
            $builder->where('idusuario', $idusuario);
        }

        if ($idestado !== null) {
            $builder->where('idestado', $idestado);
        }

        return $builder->selectSum('total')->get()->getRow()->total ?? 0;
    }

    public function pedidoTotalSumaUsuario($parametro, $valor, $idestado, $idppago, $idusuario)
    {
        $builder = $this->builder();

        if ($parametro != '' && $valor != '') {
            if ($parametro == 'mes') {
                $builder->where('MONTH(fecha)', $valor);
            } else {
                $builder->like($parametro, $valor);
            }
        }

        if ($idestado > 0) $builder->where('idestado', $idestado);
        if ($idppago > 0) $builder->where('idppago', $idppago);
        if ($idusuario > 0) $builder->where('idusuario', $idusuario);

        return $builder->selectSum('total')->get()->getRow()->total ?? 0;
    }

    public function obtenerByIdCuponIdProductoTalla($idcupon, $idproductotalla)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pedido p');
        $builder->join('pedido_cupon', 'pedido_cupon.idpedido = p.idpedido');
        $builder->join('pedidodetalle', 'pedidodetalle.idpedido = p.idpedido');
        $builder->where('pedido_cupon.idcupon', $idcupon);
        $builder->where('pedidodetalle.idproductotalla', $idproductotalla);

        return $builder->countAllResults();
    }

    public function obtenerPorCodigo($numero)
    {
        return $this->where('numero', $numero)->first();
    }
}
