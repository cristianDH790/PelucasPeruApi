<?php

namespace App\Models;


use App\Entities\ProductoEntity;
use CodeIgniter\Model;

class ProductoModel extends Model
{
    protected $table      = 'producto';
    protected $primaryKey = 'idproducto';

    protected $useAutoIncrement = true;

    protected $returnType     = ProductoEntity::class;
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'idestado',
        'idproductocategoria',
        'idpdestacado',
        'idppromocion',        // corregido a 'idppromocion' según tabla (no 'idpromocion')
        'idpajuste',        // corregido a 'idppromocion' según tabla (no 'idpromocion')
        'idplongitud',        // corregido a 'idppromocion' según tabla (no 'idpromocion')
        'idpcontrolstock',        // corregido a 'idppromocion' según tabla (no 'idpromocion')
        'idmarca',
        'codigo',
        'nombre',
        'urlamigable',
        'resumen',
        'resumen2',
        'contenido',           // reemplaza 'descripcionseo' y 'descripcion' por 'contenido' si así es el campo correcto
        'stock',               // agregado para que esté permitido si usas ese campo
        'preciolista',
        'precioventa',
        'peso',
        'orden',
        'compraxcliente',      // agregado para permitir ese campo
        'fechapublicacion',
        'fecha'
    ];


    protected $useTimestamps = false;
    protected $createdField  = 'fecha';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;



    // Obtener curso por ID
    public  function obtenerPorId($idproducto)
    {
        return $this->where('idproducto', $idproducto)->first();
    }


    public function obtenerPorUrlAmigable($urlamigable)
    {
        $subQuery = "
        SELECT idproducto, urlimagen
        FROM (
            SELECT 
                pi.idproducto,
                pi.urlimagen,
                ROW_NUMBER() OVER (
                    PARTITION BY pi.idproducto 
                    ORDER BY 
                        CASE WHEN pi.idpdestacado = 1 THEN 0 ELSE 1 END,
                        pi.orden ASC,
                        pi.idproductoimagen ASC
                ) AS rn
            FROM productoimagen pi
        ) AS imagenes
        WHERE rn = 1
    ";

        $builder = $this->db->table('producto p');
        $builder->select('p.*, img.urlimagen AS urlimagen');
        $builder->join("($subQuery) img", 'img.idproducto = p.idproducto', 'left');
        $builder->where('p.urlamigable', $urlamigable);

        return $builder->get()->getRow(); // Devuelve solo 1 resultado como objeto
    }




    // public function obtenerPorUrlAmigable($urlamigable)
    // {
    //     return $this->where('urlamigable', $urlamigable)->first();
    // }



    // public function buscarPor($ordencriterio = '', $ordentipo = '', $parametro = '', $valor = '', $idestado = 0, $idproductocategoria = 0, $idpdestacado = 0, $idppromocion = 0, $inicio = null, $registros = null)
    // {
    //     $builder = $this->db->table($this->table);
    //     $builder->select('*');

    //     // Filtro por búsqueda
    //     if (!empty($parametro) && !empty($valor)) {
    //         $builder->like($parametro, trim($valor), 'both');
    //     }

    //     if ($idestado > 0)
    //         $builder->where('idestado', $idestado);
    //     if ($idproductocategoria > 0)
    //         $builder->where('idproductocategoria', $idproductocategoria);
    //     if ($idppromocion > 0)
    //         $builder->where('idppromocion', $idppromocion);
    //     if ($idpdestacado > 0)
    //         $builder->where('idpdestacado', $idpdestacado);


    //     // Ordenamiento
    //     if (!empty($ordencriterio) && !empty($ordentipo)) {
    //         $builder->orderBy($ordencriterio, $ordentipo);
    //     }

    //     // Paginación
    //     if ($registros > 0) {
    //         $builder->limit($registros, $inicio);
    //     }

    //     return $builder->get()->getResult();
    // }

    /*public function buscarPor(
        $ordencriterio = '',
        $ordentipo = '',
        $parametro = '',
        $valor = '',
        $idestado = 0,
        $idproductocategoria = 0,
        $idpdestacado = 0,
        $idppromocion = 0,
        $inicio = null,
        $registros = null
    ) {
        $builder = $this->db->table($this->table . ' p'); // p para productobase
        $builder->select('p.*, pi.urlimagen');

        // Subconsulta para obtener el idproductoimagen mínimo por idproductobase con idptipo=578
        $subQuery = $this->db->table('productoimagen pi1')
            ->select('pi1.idproductobase, pi1.urlimagen')
            ->join(
                '(SELECT idproductobase, MIN(idproductoimagen) AS min_id FROM productoimagen WHERE idptipo = 578 GROUP BY idproductobase) pi2',
                'pi1.idproductobase = pi2.idproductobase AND pi1.idproductoimagen = pi2.min_id',
                'inner'
            );

        // Hacemos join con la subconsulta
        $builder->join("({$subQuery->getCompiledSelect()}) pi", 'pi.idproductobase = p.idproductobase', 'left', false);

        // Filtros existentes
        if (!empty($parametro) && !empty($valor)) {
            $builder->like('p.' . $parametro, trim($valor), 'both');
        }

        if ($idestado > 0)
            $builder->where('p.idestado', $idestado);

        if ($idproductocategoria > 0)
            $builder->where('p.idproductocategoria', $idproductocategoria);

        if ($idppromocion > 0)
            $builder->where('p.idppromocion', $idppromocion);

        if ($idpdestacado > 0)
            $builder->where('p.idpdestacado', $idpdestacado);

        // Ordenamiento
        if (!empty($ordencriterio) && !empty($ordentipo)) {
            $builder->orderBy('p.' . $ordencriterio, $ordentipo);
        }

        // Paginación
        if ($registros > 0) {
            $builder->limit($registros, $inicio);
        }

        return $builder->get()->getResult();
    }*/

    //     //antes esto
    // public function buscarPor(
    //     $ordencriterio ,
    //     $ordentipo ,
    //     $parametro ,
    //     $valor,
    //     $idestado ,
    //     $idproductocategoria ,
    //     $idpdestacado ,
    //     $idppromocion,
    //     $inicio ,
    //     $registros 
    // ) {
    //     $builder = $this->db->table($this->table . ' p'); // Alias 'p' para producto
    //     $builder->select('p.*, pi.urlimagen');

    //     // Subconsulta con prioridad a idpdestacado = 568, sino imagen con menor orden
    //     $subQuerySql = "
    //         SELECT idproducto, urlimagen FROM (
    //             SELECT 
    //                 pi.idproducto,
    //                 pi.urlimagen,
    //                 ROW_NUMBER() OVER (
    //                     PARTITION BY pi.idproducto 
    //                     ORDER BY 
    //                         CASE WHEN pi.idpdestacado = 568 THEN 0 ELSE 1 END,
    //                         pi.orden ASC,
    //                         pi.idproductoimagen ASC
    //                 ) AS rn
    //             FROM productoimagen pi
    //         ) AS imagenes
    //         WHERE rn = 1
    //     ";

    //     // JOIN usando subconsulta
    //     $builder->join("({$subQuerySql}) pi", 'pi.idproducto = p.idproducto', 'left', false);


    //     // Filtros
    //     if (!empty($parametro) && !empty($valor)) {
    //         $builder->like('p.' . $parametro, trim($valor), 'both');
    //     }

    //     if ($idestado > 0)
    //         $builder->where('p.idestado', $idestado);

    //     if ($idproductocategoria > 0)
    //         $builder->where('p.idproductocategoria', $idproductocategoria);

    //     if ($idppromocion > 0)
    //         $builder->where('p.idppromocion', $idppromocion);

    //     if ($idpdestacado > 0)
    //         $builder->where('p.idpdestacado', $idpdestacado);

    //     // Ordenamiento
    //     if (!empty($ordencriterio) && !empty($ordentipo)) {
    //         $builder->orderBy('p.' . $ordencriterio, $ordentipo);
    //     }

    //     // Paginación
    //     if ($registros > 0) {
    //         $builder->limit($registros, $inicio);
    //     }

    //     return $builder->get()->getResult();
    // }

    public function buscarPor(
        $ordencriterio,
        $ordentipo,
        $parametro,
        $valor,
        $idestado,
        $idproductocategoria,
        $idpdestacado,
        $idppromocion,
        $idmarca,
        $idcupon,
        $inicio,
        $registros
    ) {
        $builder = $this->db->table($this->table . ' p'); // Alias 'p' para producto

        $builder->select('p.*, pi.urlimagen, pc.urlamigable AS categoria_urlamigable');

        // JOIN con productocategoria
        $builder->join('productocategoria pc', 'pc.idproductocategoria = p.idproductocategoria', 'left');

        // Subconsulta con prioridad a idpdestacado = 568, sino imagen con menor orden
        $subQuerySql = "
        SELECT idproducto, urlimagen FROM (
            SELECT 
                pi.idproducto,
                pi.urlimagen,
                ROW_NUMBER() OVER (
                    PARTITION BY pi.idproducto 
                    ORDER BY 
                        CASE WHEN pi.idpdestacado = 568 THEN 0 ELSE 1 END,
                        pi.orden ASC,
                        pi.idproductoimagen ASC
                ) AS rn
            FROM productoimagen pi
        ) AS imagenes
        WHERE rn = 1
    ";

        // JOIN usando subconsulta
        $builder->join("({$subQuerySql}) pi", 'pi.idproducto = p.idproducto', 'left', false);

        // 👉 JOIN con tabla intermedia SOLO SI se pasa idcupon
        if ($idcupon > 0) {
            $builder->join('producto_cupon pcupon', 'pcupon.idproducto = p.idproducto');
            $builder->where('pcupon.idcupon', $idcupon);
        }

        // Filtros
        if (!empty($parametro) && !empty($valor)) {
            $builder->like('p.' . $parametro, trim($valor), 'both');
        }

        if ($idestado > 0)
            $builder->where('p.idestado', $idestado);

        if ($idproductocategoria > 0)
            $builder->where('p.idproductocategoria', $idproductocategoria);

        if ($idppromocion > 0)
            $builder->where('p.idppromocion', $idppromocion);

        if ($idpdestacado > 0)
            $builder->where('p.idpdestacado', $idpdestacado);
        if ($idmarca > 0)
            $builder->where('p.idmarca', $idmarca);

        // Ordenamiento
        if (!empty($ordencriterio) && !empty($ordentipo)) {
            $builder->orderBy('p.' . $ordencriterio, $ordentipo);
        }

        // Paginación
        if ($registros > 0) {
            $builder->limit($registros, $inicio);
        }

        return $builder->get()->getResult();
    }

    // $idpDestacado,
    //             $idProductoCategoria,
    //             $idPromocion


    public function buscarPorTotal($parametro, $valor,  $idestado, $idproductocategoria, $idpdestacado, $idppromocion, $idmarca, $idcupon)
    {
        $builder = $this->db->table($this->table);
        $builder->select('COUNT(*) as total');

        if ($idcupon > 0) {
            $builder->join('producto_cupon pcupon', 'pcupon.idproducto = p.idproducto');
            $builder->where('pcupon.idcupon', $idcupon);
        }
        // Filtro por búsqueda
        if (!empty($parametro) && !empty($valor)) {
            $builder->like($parametro, trim($valor), 'both');
        }


        if ($idestado > 0)
            $builder->where('idestado', $idestado);
        if ($idproductocategoria > 0)
            $builder->where('idproductocategoria', $idproductocategoria);
        if ($idppromocion > 0)
            $builder->where('idppromocion', $idppromocion);
        if ($idpdestacado > 0)
            $builder->where('idpdestacado', $idpdestacado);
        if ($idmarca > 0)
            $builder->where('idmarca', $idmarca);

        return $builder->countAllResults();
    }



    public function eliminar($idproducto): bool
    {
        $this->db->transStart();
        try {
            if (!$this->where('idproducto', $idproducto)->first()) {
                return false;
            }

            $resultado = $this->delete($idproducto);

            $this->db->transComplete();
            return $resultado;
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'Eliminar producto base falló: ' . $e->getMessage());
            return false;
        }
    }

    // public function guardar($data): int
    // {
    //     $this->db->transStart();
    //     try {
    //         if (empty($data['idproducto'])) {
    //             $this->insert($data);
    //             $id = $this->getInsertID();
    //         } else {
    //             $this->update($data['idproducto'], $data);
    //             $id = $data['idproducto'];
    //         }
    //         $this->db->transComplete();
    //         return $id;
    //     } catch (\Throwable $e) {
    //         $this->db->transRollback();
    //         var_dump($data);

    //         log_message('error', 'Error en guardar: ' . $e->getMessage());
    //         throw $e;
    //     }
    // }
    // public function guardar($data)
    // {
    //     $this->db->transStart();

    //     try {
    //         // 1. Guardar en PRODUCTOBASE
    //         $datosProducto = [
    //             'idestado' => $data['estado']['idEstado'] ?? null,
    //             'idproductocategoria' => $data['productoCategoria']['idProductoCategoria'] ?? null,
    //             'idpromocion' => $data['promocion']['idParametro'] ?? null,
    //             'idpdestacado' => $data['pDestacado']['idParametro'] ?? null,
    //             'codigo' => $data['codigo'] ?? null,
    //             'nombre' => $data['nombre'] ?? null,
    //             'urlamigable' => $data['urlAmigable'] ?? null,
    //             'resumen' => $data['resumen'] ?? null,
    //             'descripcionseo' => $data['descripcionSeo'] ?? null,
    //             'descripcion' => $data['descripcion'] ?? null,
    //             'urlimagen' => $data['urlImagen'] ?? null,
    //             'preciolista' => $data['precioLista'] ?? null,
    //             'precioventa' => $data['precioVenta'] ?? null,
    //             'peso' => $data['peso'] ?? null,
    //             'fechapublicacion' => $data['fechaPublicacion'] ?? null,
    //             'fecha' => $data['fecha'] ?? null,
    //         ];

    //         if (!empty($data['idproducto'])) {
    //             $datosProducto['idproducto'] = $data['idproducto'];
    //         }

    //         $productoId = $this->productobase->guardar($datosProducto);

    //         // // 2. Guardar en PRODUCTO
    //         // $productoData = [
    //         //     'idestado' => $data['estado']['idEstado'] ?? null,
    //         //     'idproductobase' => $productoId,
    //         //     'idempresa' => $data['producto']['idempresa'] ?? null,
    //         //     'stock' => $data['producto']['stock'] ?? 0,

    //         // ];

    //         // $this->producto->insert($productoData);

    //         // 3. Guardar en PRODUCTOBASE_MARCA
    //         $marcaId = $data['marca']['idMarca'] ?? null;
    //         if ($marcaId) {
    //             $this->db->table('productobase_marca')->insert([
    //                 'idproductobase' => $productoId,
    //                 'idmarca' => $marcaId
    //             ]);
    //         }

    //         $this->db->transComplete();

    //         if ($this->db->transStatus() === false) {
    //             throw new \Exception('Error al guardar el producto');
    //         }

    //         return $this->respond(['mensaje' => 'Guardado correctamente', 'id' => $productoId]);
    //     } catch (\Throwable $e) {
    //         $this->db->transRollback();
    //         log_message('error', 'Error en guardarProductoCompleto: ' . $e->getMessage());
    //         return $this->failServerError('Error al guardar: ' . $e->getMessage());
    //     }
    // }
    public function guardar($data)
    {
        $this->db->transStart();

        try {
            // Guardar en PRODUCTOBASE
            // $datosProducto = [
            //     'idestado' => $data['idestado'] ?? null,
            //     'idproductocategoria' => $data['idproductocategoria'] ?? null,
            //     'idppromocion' => $data['idppromocion'] ?? null,
            //     'idpdestacado' => $data['idpdestacado'] ?? null,
            //     'codigo' => $data['codigo'] ?? null,
            //     'nombre' => $data['nombre'] ?? null,
            //     'urlamigable' => $data['urlamigable'] ?? null,
            //     'resumen' => $data['resumen'] ?? null,
            //     'descripcionseo' => $data['descripcionseo'] ?? null,
            //     'descripcion' => $data['descripcion'] ?? null,
            //     'urlimagen' => $data['urlimagen'] ?? null,
            //     'preciolista' => $data['preciolista'] ?? null,
            //     'precioventa' => $data['precioventa'] ?? null,
            //     'peso' => $data['peso'] ?? null,
            //     'fechapublicacion' => $data['fechapublicacion'] ?? null,

            // ];

            // Verifica si es actualización o inserción
            if (!empty($data['idproducto'])) {
                $this->update($data['idproducto'], $data);
                $productoId = $data['idproducto'];
            } else {
                $this->insert($data);
                $productoId = $this->getInsertID();
            }

            // Guardar en PRODUCTOBASE_MARCA
            $marcaId = $data['idmarca'] ?? null;
            if ($marcaId) {
                // Elimina la relación previa si es actualización
                if (!empty($data['idproducto'])) {
                    $this->db->table('producto_marca')
                        ->where('idproducto', $productoId)
                        ->delete();
                }

                $this->db->table('producto_marca')->insert([
                    'idproducto' => $productoId,
                    'idmarca' => $marcaId
                ]);
            }


            $this->db->transComplete();

            if ($this->db->transStatus() === false) {
                throw new \Exception('Error al guardar el producto');
            }

            return $productoId;
        } catch (\Throwable $e) {
            $this->db->transRollback();
            log_message('error', 'Error en guardar Producto: ' . $e->getMessage());
            throw $e;
        }
    }
}
