<?php

namespace App\Models;

use App\Entities\EmpresaEntity;
use App\Entities\Noticia;
use App\Entities\NoticiaEntity;
use App\Entities\PedidoEntity;
use App\Entities\ProductoBaseEntity;
use App\Entities\ProductoEntity;
use CodeIgniter\Model;

class PedidoDetalleModel extends Model
{
    protected $table      = 'pedidodetalle';
    protected $primaryKey = 'idpedidodetalle';

    protected $useAutoIncrement = true;

    protected $returnType     = PedidoEntity::class;
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'idestado',
        'idpedido',
        'idproducto',
        'cantidad',
        'peso',
        'precio',
        'descuento',
        'total',


    ];

    protected $useTimestamps = false;
    protected $createdField  = 'fecha';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;


    public function pedidoDetalleFind($ordencriterio, $ordentipo, $parametro, $valor, $idpedido, $idproductotalla, $inicio, $registros)
    {
        $builder = $this->db->table('pedidodetalle as p');

        $builder->where('p.idpedidodetalle >=', 1);

        if (!empty($parametro) && !empty($valor)) {
            $builder->like($parametro, $valor);
        }

        if ($idpedido > 0) {
            $builder->where('p.idpedido', $idpedido);
        }

        if ($idproductotalla > 0) {
            $builder->where('p.idproductotalla', $idproductotalla);
        }

        if (!empty($ordencriterio) && !empty($ordentipo)) {
            $builder->orderBy($ordencriterio, $ordentipo);
        }

        if ($inicio >= 0 && $registros > 0) {
            $builder->limit($registros, $inicio);
        }

        return $builder->get()->getResult(); // Devuelve array de objetos
    }
    public function pedidoDetalleFindTotal($parametro, $valor, $idpedido, $idproductotalla)
    {
        $builder = $this->db->table('pedidodetalle as p');
        $builder->where('p.idpedidodetalle >=', 1);

        if (!empty($parametro) && !empty($valor)) {
            $builder->like($parametro, $valor);
        }

        if ($idpedido > 0) {
            $builder->where('p.idpedido', $idpedido);
        }

        if ($idproductotalla > 0) {
            $builder->where('p.idproductotalla', $idproductotalla);
        }

        return $builder->countAllResults();
    }
    public function pedidoDetalleByPedido($idpedido)
    {
        $builder = $this->db->table('pedidodetalle');
        $builder->join('productotalla', 'productotalla.idproductotalla = pedidodetalle.idproductotalla');
        $builder->join('productocolor', 'productocolor.idproductocolor = productotalla.idproductocolor');
        $builder->join('producto', 'producto.idproducto = productocolor.idproducto');
        $builder->where('pedidodetalle.idpedido', $idpedido);

        $builder->select('pedidodetalle.*, producto.nombre');

        $builder->select("CONCAT(
        producto.codigo,
        (SELECT color.codigoproductotalla 
         FROM productocolor pc
         INNER JOIN color ON color.idcolor = pc.idcolor
         WHERE productocolor.idproductocolor = productotalla.idproductocolor
         LIMIT 1),
        (SELECT talla.codigo 
         FROM talla 
         WHERE talla.idtalla = productotalla.idtalla
         LIMIT 1)
    ) AS codigo", false);

        return $builder->get()->getResult();
    }
    public function obtenerAtributos($idpedidodetalle)
    {
        $builder = $this->db->table('pedidodetalle as pd');
        $builder->distinct();
        $builder->select('pa.*, p.nombre as preferencianombre');
        $builder->join('pedido_preferencia', 'pedido_preferencia.idpedidodetalle = pd.idpedidodetalle', 'left');
        $builder->join('preferenciaatributo as pa', 'pa.idpreferenciaatributo = pedido_preferencia.idpreferenciaatributo', 'left');
        $builder->join('preferencia as p', 'p.idpreferencia = pa.idpreferencia', 'left');
        $builder->where('pd.idpedidodetalle', $idpedidodetalle);

        return $builder->get()->getResult();
    }
    public function pedidoDetalleByProducto($idproductotalla)
    {
        $builder = $this->db->table('pedidodetalle as pd');
        $builder->select('p.*');
        $builder->join('productotalla as p', 'pd.idproductotalla = p.idproductotalla', 'left');
        $builder->where('p.idproductotalla', $idproductotalla);

        return $builder->countAllResults();
    }
}
