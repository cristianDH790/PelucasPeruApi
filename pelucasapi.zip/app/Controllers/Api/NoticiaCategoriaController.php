<?php

namespace App\Controllers\Api;


use App\Entities\NoticiaCategoriaEntity;
use App\Helpers\Paginator;
use App\Helpers\Permisos;
use App\Models\EstadoModel;
use App\Models\NoticiaCategoriaModel;
use App\Validation\NoticiaCategoriaValidation;
use CodeIgniter\RESTful\ResourceController;

class NoticiaCategoriaController extends ResourceController
{
    protected $permiso;
    protected $noticiacategoria;
    protected $estado;

    public function __construct()
    {
        $this->permiso = new Permisos();
        $this->noticiacategoria = new NoticiaCategoriaModel();
        $this->estado = new EstadoModel();
    }

    private function verificarPermiso(string $permiso)
    {


        $token = $this->request->getHeaderLine('X-Authorization');
        $token = str_replace('Bearer ', '', $token);

        if (!$token) {
            return $this->failUnauthorized('Token no proporcionado');
        }
        $resultado = $this->permiso->obtenerPermisosDesdeToken($token);

        if (isset($resultado['error'])) {
            return $this->failUnauthorized($resultado['error']);
        }

        $permisos = $resultado['authorities'] ?? [];

        if (!in_array($permiso, $permisos)) {
            return $this->failForbidden("No tienes permiso: {$permiso}");
        }

        return null; // Permiso concedido
    }

    public  function obtenerPorId($idnoticiacategoria)
    {
        if ($respuesta = $this->verificarPermiso('api_noticia_categoria_obtenerPorId')) {
            return $respuesta;
        }
        $noticiacategoria = $this->noticiacategoria->obtenerPorId($idnoticiacategoria);

        if (!$noticiacategoria) {
            return $this->respond(['mensaje' => 'No existe la noticia categoria solicitada'], 404);
        } else {

            $noticiaCategoriaEntity = new NoticiaCategoriaEntity($noticiacategoria);



            $noticiaCategoriaEntity->estado = $this->estado->obtenerPorId($noticiacategoria->idestado);



            // Convertir a array
            $resultado = $noticiaCategoriaEntity->toArray();

            return $this->respond($resultado, 200);
        }
    }

    public function listar()
    {
        if ($respuesta = $this->verificarPermiso('api_noticia_categoria_listar')) {
            return $respuesta;
        }
        // Verificar si es POST
        if (!$this->request->is('post')) {
            return $this->fail('Método no permitido. Se requiere POST.', 405);
        }

        $request = $this->request;

        // Parámetros de búsqueda y orden
        $ordencriterio = $request->getVar('ordenCriterio') ?? 'fechapublicacion';
        $ordentipo = $request->getVar('ordenTipo') ?? 'asc';
        $parametro = $request->getVar('parametro') ?? '';
        $valor = $request->getVar('valor') ?? '';
        $idestado = (int) ($request->getVar('idEstado') ?? 0);

        // Parámetros de paginación
        $pagina = (int) ($request->getVar('pagina') ?? 1);
        $registros = (int) ($request->getVar('registros') ?? 10);

        // Total de registros
        $total = $this->noticiacategoria->buscarPorTotal(
            $parametro,
            $valor,
            $idestado,

        );

        $paginator = new Paginator($pagina, $registros, $total);
        // Consulta paginada
        $noticiacategorias = $this->noticiacategoria->buscarPor(
            $ordencriterio,
            $ordentipo,
            $parametro,
            $valor,
            $idestado,

            $paginator->getFirstElement(),
            $paginator->getSize()
        );

        // Convertir resultados a entidad
        $resultado = [];
        foreach ($noticiacategorias as $row) {

            $noticiaCategoriaEntity = new NoticiaCategoriaEntity((array)$row);

            $noticiaCategoriaEntity->estado = $this->estado->obtenerPorId($row->idestado);



            $resultado[] = $noticiaCategoriaEntity->toArray();
        }

        // Respuesta JSON con paginación y datos
        return $this->respond([
            'paginator' => $paginator->enviar(),
            'content' => $resultado
        ]);
    }
    public function guardar()
    {
        if ($respuesta = $this->verificarPermiso('api_noticia_categoria_guardar')) {
            return $respuesta;
        }
        $request = $this->request;

        $data = $request->getJSON(true);
        $noticiacategoriaRequest = new NoticiaCategoriaValidation();
        $errores = $noticiacategoriaRequest->NoticiaCategoriaGuardarValidation($data);

        if (!empty($errores)) {
            return $this->response
                ->setStatusCode(422)
                ->setJSON(['errors' => $errores]);
        }

        $datosValidados = [
            'idestado' => $data['estado']['idEstado'] ?? null,
            'idrnoticiacategoria' => $data['rNoticiaCategoria']['idNoticiaCategoria'] ?? null,
            'nombres' => $data['nombres'] ?? null,
            'orden' => $data['orden'] ?? null,

            'urlamigable' => $data['urlAmigable'] ?? null,
            'descripcionseo' => $data['descripcionSeo'] ?? null,

        ];



        $noticiacategoriaId = $this->noticiacategoria->guardar($datosValidados);
        $noticiacategoria = $this->noticiacategoria->find($noticiacategoriaId);
        if ($noticiacategoria) {


            $noticiaCategoriaEntity = new NoticiaCategoriaEntity($noticiacategoria);
            $noticiaCategoriaEntity->estado = $this->estado->obtenerPorId($noticiacategoria->idestado);




            return $this->respond([
                "mensaje" => 'noticiacategoria registrado con éxito',
                "noticiacategoria" => $noticiaCategoriaEntity->toArray()
            ], 201);
        } else {

            return $this->respond(["mensaje" => "Error al registrar noticiacategoria"], 500);
        }
    }

    public function actualizar()
    {
        if ($respuesta = $this->verificarPermiso('api_noticia_categoria_actualizar')) {
            return $respuesta;
        }
        $request = $this->request;

        $data = $request->getJSON(true);
        $noticiacategoriaRequest = new NoticiaCategoriaValidation();
        $errores = $noticiacategoriaRequest->NoticiaCategoriaActualizarValidation($data);

        if (!empty($errores)) {
            return $this->response
                ->setStatusCode(422)
                ->setJSON(['errors' => $errores]);
        }
        $datosValidados = [
            'idnoticiacategoria' => (int) $data['idNoticiaCategoria'] ?? null,
            'idestado' => $data['estado']['idEstado'] ?? null,
            'idrnoticiacategoria' => $data['rNoticiaCategoria']['idNoticiaCategoria'] ?? null,
            'orden' => $data['orden'] ?? null,

            'nombres' => $data['nombres'] ?? null,
            'urlamigable' => $data['urlAmigable'] ?? null,
            'descripcionseo' => $data['descripcionSeo'] ?? null,
        ];

        $noticiacategoriaId = $this->noticiacategoria->guardar($datosValidados);
        $noticiacategoria = $this->noticiacategoria->find($noticiacategoriaId);
        if ($noticiacategoria) {

            $noticiaCategoriaEntity = new NoticiaCategoriaEntity($noticiacategoria);
            $noticiaCategoriaEntity->estado = $this->estado->obtenerPorId($noticiacategoria->idestado);



            return $this->respond([
                "mensaje" => 'noticiacategoria actualizado con éxito',
                "noticiacategoria" =>  $noticiaCategoriaEntity->toArray()
            ], 201);
        } else {

            return $this->respond(["mensaje" => "Error al actualizar el noticiacategoria"], 500);
        }
    }

    public function eliminar($idnoticiacategoria)
    {
        if ($respuesta = $this->verificarPermiso('api_noticia_categoria_eliminar')) {
            return $respuesta;
        }
        if ($this->noticiacategoria->eliminar($idnoticiacategoria)) {
            return $this->respond(['mensaje' => 'noticiacategoria eliminado con éxito']);
        } else {
            return $this->failNotFound('No se encontró la noticiacategoria');
        }
    }
}
