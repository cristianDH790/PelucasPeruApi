<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class PedidoEntity
{
    public $idpedido;
    public $idusuario;
    public $idformapago;
    public $identrega;
    public $idppago;
    public $idestado;
    public $referencia;
    public $peso;
    public $costoenvio;
    public $comision;
    public $subtotal;
    public $descuento;
    public $total;
    public $fechapedido;
    public $fechaentrega;
    public $observacion;
    public $urlconstancia;
    public $fechareporte;
    public $fechaconfirmacion;

    // Relaciones
    public $estado;
    public $usuario;
    public $formapago;
    public $entrega;
    public $ppago;



    public function __construct($data = null)
    {
        if ($data) {
            if (is_array($data)) {
                $this->idpedido          = $data['idpedido'] ?? null;
                $this->idusuario         = $data['idusuario'] ?? null;
                $this->idformapago       = $data['idformapago'] ?? null;
                $this->identrega         = $data['identrega'] ?? null;
                $this->idppago           = $data['idppago'] ?? null;
                $this->idestado          = $data['idestado'] ?? null;
                $this->referencia        = $data['referencia'] ?? null;
                $this->peso              = $data['peso'] ?? null;
                $this->costoenvio        = $data['costoenvio'] ?? null;
                $this->comision          = $data['comision'] ?? null;
                $this->subtotal          = $data['subtotal'] ?? null;
                $this->descuento         = $data['descuento'] ?? null;
                $this->total             = $data['total'] ?? null;
                $this->fechapedido       = $data['fechapedido'] ?? null;
                $this->fechaentrega      = $data['fechaentrega'] ?? null;
                $this->observacion       = $data['observacion'] ?? null;
                $this->urlconstancia     = $data['urlconstancia'] ?? null;
                $this->fechareporte      = $data['fechareporte'] ?? null;
                $this->fechaconfirmacion = $data['fechaconfirmacion'] ?? null;
            } elseif (is_object($data)) {
                $this->idpedido          = $data->idpedido ?? null;
                $this->idusuario         = $data->idusuario ?? null;
                $this->idformapago       = $data->idformapago ?? null;
                $this->identrega         = $data->identrega ?? null;
                $this->idppago           = $data->idppago ?? null;
                $this->idestado          = $data->idestado ?? null;
                $this->referencia        = $data->referencia ?? null;
                $this->peso              = $data->peso ?? null;
                $this->costoenvio        = $data->costoenvio ?? null;
                $this->comision          = $data->comision ?? null;
                $this->subtotal          = $data->subtotal ?? null;
                $this->descuento         = $data->descuento ?? null;
                $this->total             = $data->total ?? null;
                $this->fechapedido       = $data->fechapedido ?? null;
                $this->fechaentrega      = $data->fechaentrega ?? null;
                $this->observacion       = $data->observacion ?? null;
                $this->urlconstancia     = $data->urlconstancia ?? null;
                $this->fechareporte      = $data->fechareporte ?? null;
                $this->fechaconfirmacion = $data->fechaconfirmacion ?? null;
            }
        }
    }

    public function toArray()
    {
        $data = [
            'idPedido'          => (int) $this->idpedido,
            'idUsuario'         => (int) $this->idusuario,
            'idFormaPago'       => (int) $this->idformapago,
            'idEntrega'         => (int) $this->identrega,
            'idpPago'           => (int) $this->idppago,
            'idEstado'          => (int) $this->idestado,
            'referencia'        => $this->referencia,
            'peso'              => $this->peso,
            'costoEnvio'        => $this->costoenvio,
            'comision'          => $this->comision,
            'subtotal'          => $this->subtotal,
            'descuento'         => $this->descuento,
            'total'             => $this->total,
            'fechaPedido'       => $this->fechapedido,
            'fechaEntrega'      => $this->fechaentrega,
            'observacion'       => $this->observacion,
            'urlConstancia'     => $this->urlconstancia,
            'fechaReporte'      => $this->fechareporte,
            'fechaConfirmacion' => $this->fechaconfirmacion,
        ];

        // Relaciones si existen
        if ($this->estado !== null) {
            $data['estado'] = $this->estado->toArray();
        }
        if ($this->usuario !== null) {
            $data['usuario'] = $this->usuario->toArray();
        }
        if ($this->formapago !== null) {
            $data['formaPago'] = $this->formapago->toArray();
        }
        if ($this->entrega !== null) {
            $data['entrega'] = $this->entrega->toArray();
        }
        if ($this->ppago !== null) {
            $data['pPago'] = $this->ppago->toArray();
        }

        return $data;
    }
}
